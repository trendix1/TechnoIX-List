CollabNote Pro — Auth ZIP
=========================

This project is a skeleton for CollabNote Pro with:
- React + Vite + Tailwind
- Firebase Authentication (Email/Password + Google sign-in)
- Simple per-user project list (stored in localStorage)
- Placeholder collaborative workspace (replace workspace/Collab.jsx with full UI)

Setup steps:
1. Unzip the project directory.
2. Install dependencies:
   npm install
3. Configure Firebase:
   - Go to https://console.firebase.google.com and create a project (or use existing).
   - In the Firebase console: Authentication -> Sign-in method -> Enable Email/Password and Google.
   - Create a Web App (</>) to get the Firebase config object.
   - Replace the placeholder values in src/firebase.js with your config.
4. Start dev server:
   npm run dev
5. Open http://localhost:5173

Notes:
- Projects are currently stored per-user in localStorage (key: cn_projects_<uid>).
- For team projects synced across users, integrate Firestore or Realtime Database and migrate project storage there.
- To replace the placeholder workspace with the full CollabNotePro UI, copy the CollabNotePro component into src/workspace/Collab.jsx (or import it) and ensure dependencies (html2canvas, peerjs) are installed.

If you want, I can:
- Replace the placeholder workspace with the full UI now.
- Add Firestore integration for shared projects and invitations.
- Add server example for Yjs (y-websocket) for scalable real-time sync.
