import React, { useEffect, useState, createContext, useContext } from 'react';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';
import { auth } from './firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';

const AuthContext = createContext();

export function useAuth(){ return useContext(AuthContext); }

export default function App(){
  const [user, setUser] = useState(null);
  const [initializing, setInitializing] = useState(true);
  useEffect(()=>{
    const unsub = onAuthStateChanged(auth, u => {
      setUser(u);
      setInitializing(false);
    });
    return unsub;
  },[]);
  if(initializing) return <div className='container'><p>Loading...</p></div>;
  return (
    <AuthContext.Provider value={{user, setUser}}>
      <div className='container'>
        <Header user={user} />
        {!user ? <AuthPages /> : <Dashboard />}
      </div>
    </AuthContext.Provider>
  );
}

function AuthPages(){
  const [mode, setMode] = useState('login');
  return (
    <div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
      {mode==='login' ? <Login /> : <Register />}
      <div className='card'>
        <h2 className='text-xl font-semibold mb-2'>Why sign up?</h2>
        <p className='mb-4'>With an account you can create projects, invite teammates, and collaborate in realtime.</p>
        <div className='flex gap-2'>
          <button className='btn' onClick={() => setMode('login')}>Login</button>
          <button className='btn bg-green-600 hover:bg-green-700' onClick={() => setMode('register')}>Register</button>
        </div>
      </div>
    </div>
  );
}

function Header({user}){
  return (
    <header className='flex items-center gap-4 mb-6'>
      <h1 className='text-2xl font-bold'>CollabNote Pro — Auth</h1>
      <div className='ml-auto'>
        {user ? (
          <div className='flex items-center gap-2'>
            <span className='text-sm opacity-70'>Hi, {user.displayName || user.email}</span>
            <button className='btn bg-red-600' onClick={()=>signOut(auth)}>Logout</button>
          </div>
        ) : null}
      </div>
    </header>
  );
}
