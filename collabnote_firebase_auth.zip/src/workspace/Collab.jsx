import React, { useEffect, useState } from 'react';

export default function Collab(){
  const [projectId, setProjectId] = useState(null);
  useEffect(()=>{
    function check(){ const m = /#project=([A-Za-z0-9-]+)/.exec(window.location.hash); setProjectId(m?m[1]:null); }
    window.addEventListener('hashchange', check); check();
    return ()=>window.removeEventListener('hashchange', check);
  },[]);
  if(!projectId) return null;
  return (
    <div className='card'>
      <h2 className='text-lg font-semibold mb-2'>Project: {projectId}</h2>
      <p className='text-sm opacity-70 mb-4'>This opens the collaborative workspace. Replace <code>workspace/Collab.jsx</code> with the full CollabNotePro component for the rich editor & diagramming features.</p>
      <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
        <div className='p-3 rounded border'>
          <h3 className='font-medium'>Notes (placeholder)</h3>
          <div contentEditable className='border p-2 mt-2 min-h-[120px] bg-white dark:bg-gray-800'></div>
        </div>
        <div className='p-3 rounded border'>
          <h3 className='font-medium'>Structure (placeholder)</h3>
          <div className='min-h-[120px] flex items-center justify-center text-sm opacity-60'>Drag nodes UI goes here — replace with the CollabNotePro component.</div>
        </div>
      </div>
    </div>
  );
}
